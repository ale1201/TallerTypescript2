import { Course } from './course.js';

export const dataCourses = [
  new Course("Desarrollo de SW", "Jose Bocanegra", 3),
  new Course("Práctica social", "David Felipe Parga", 3),
  new Course("Optimización", "Luis Felipe Giraldo", 5),
  new Course("Sistemas digitales", "Fredy Enrique Segura", 3),
  new Course("Diseño de algoritmos", "Jorge Alexander Duitama", 5),
  new Course("Arquitectura emrpesarial", "Camila Romero", 3),
  new Course("Ecuaciones diferenciales", "Mikhail Malakhaltsev", 3)
]