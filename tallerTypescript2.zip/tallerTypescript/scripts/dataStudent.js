import { Student } from './student.js';
export var dataStudent = new Student(["Código", 201728807], ["Cédula", 1000851284], ["Edad", 20], ["Dirección", "calle 135c #9a-80"], ["Teléfono", 3133064952]);
