var Student = /** @class */ (function () {
    function Student(codigo, cedula, edad, direccion, telefono) {
        this.codigo = codigo;
        this.cedula = cedula;
        this.edad = edad;
        this.direccion = direccion;
        this.telefono = telefono;
    }
    return Student;
}());
export { Student };
