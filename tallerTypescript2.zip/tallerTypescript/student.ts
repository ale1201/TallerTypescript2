export class Student {
    codigo: [string, number];
    cedula: [string, number];
    edad: [string, number];
    direccion: [string, string];
    telefono: [string, number];
  
    constructor(codigo: [string, number], cedula: [string, number], edad: [string, number], direccion: [string, string], telefono: [string, number]) {
      this.codigo = codigo;
      this.cedula = cedula;
      this.edad = edad;
      this.direccion = direccion;
      this.telefono = telefono;
    }
  }